
<html>
    <head>
        <title>Tabela com Array</title>
        <meta charset="utf-8"/>
    </head>
    <body>
        <table border='2'>
            <tr>
                <th>Turma</th>
                <th>Disciplina</th>
                <th>Semana</th>
                <th>Professor</th>
            </tr>
            <?php
                include "tabela.inc";
            ?>
        </table>
    </body>
</html>